<?php
session_start();
// Redirect to login if not logged in
if(!isset($_SESSION['email'])) {
    header("Location: login.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Incentive Management System</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }
        .container {
            max-width: 800px;
            margin: 20px auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h1 {
            text-align: center;
            color: #333;
        }
        h2 {
            color: #333;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        th, td {
            border: 1px solid #ccc;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
        form {
            margin-bottom: 20px;
        }
        label {
            font-weight: bold;
        }
        input[type="text"], select {
            width: 100%;
            padding: 8px;
            margin-top: 5px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }
        button {
            padding: 10px 20px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        button:hover {
            background-color: #45a049;
        }
        .logout {
            position: absolute;
            top: 20px;
            right: 20px;
        }
        .logout button {
            background-color: #f44336;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Welcome to Incentive Management System</h1>
        <div class="logout">
            <form action="logout.php" method="post">
                <button type="submit">Logout</button>
            </form>
        </div>
        
        <h2>Incentive Calculation</h2>
        <form id="incentiveForm">
            <label for="sales">Sales Results:</label>
            <input type="text" id="sales" name="sales" placeholder="Enter sales results">
            <button type="button" onclick="calculateIncentive()">Calculate Incentive</button>
        </form>
        <div id="incentiveResult"></div>
        
        <h2>Holiday Package Management</h2>
        <form id="holidayForm">
            <label for="holidayName">Holiday Name:</label>
            <select id="holidayName" name="holidayName">
                <option value="select">select</option>
                <option value="christmas">Christmas</option>
                <option value="holi">Holi</option>
                <option value="goodfriday">Good Friday</option>
            </select>
            <label for="duration">Duration (Nights):</label>
            <select id="duration" name="duration">
                <option value="select">select</option>
                <option value="1">1</option>
                <option value="2">2</option>
                <option value="3">3</option>
                <option value="4">4</option>
                <option value="5">5</option>
                <option value="6">6</option>
                <option value="7">7</option>
                <option value="8">8</option>
                <option value="9">9</option>
            </select>
            <label for="destination">Destination:</label>
            <select id="destination" name="destination">
                <option value="select">select</option>
                <option value="goa">Goa</option>
                <option value="lonavala">Lonavala</option>
                <option value="kedarnath">Kedarnath</option>
            </select>
            <label for="location">Location:</label>
            <select id="location" name="location">
                <option value="select">select</option>
                <option value="goa">Goa</option>
                <option value="lonavala">Lonavala</option>
                <option value="kedarnath">Kedarnath</option>
            </select>
            <label for="amenities">Amenities:</label>
            <select id="amenities" name="amenities" multiple>
                <option value="wifi">Free WiFi</option>
                <option value="parking">Parking</option>
                <option value="hairdryer">Hairdryer</option>
            </select>
            <button type="button" onclick="addHoliday()">Add</button>
            <button type="button" onclick="editHoliday()">Edit</button>
            <button type="button" onclick="deleteHoliday()">Delete</button>
        </form>
    </div>

    <script>
        function calculateIncentive() {
            var sales = parseFloat(document.getElementById('sales').value);
            var incentive = 0;
            if (sales >= 10000 && sales < 20000) {
                incentive = sales * 0.015;
            } else if (sales >= 20000 && sales < 30000) {
                incentive = sales * 0.03;
            } else if (sales >= 30000 && sales < 50000) {
                incentive = sales * 0.035 + 1000;
            } else if (sales >= 50000) {
                incentive = sales * 0.05;
                // Eligible for holiday
            }
            document.getElementById('incentiveResult').innerText = 'Incentive: $' + incentive.toFixed(2);
        }

        function addHoliday() {
            // Logic for adding holiday
        }

        function editHoliday() {
            // Logic for editing holiday
        }

        function deleteHoliday() {
            // Logic for deleting holiday
        }
    </script>
</body>
</html>
